#!/usr/bin/env python3
"""
Memory System Integration Module
=================================
Drop this into any project to activate the autonomous memory system.

Usage:
    # In your agent/script entry point:
    from memory_integration import auto_memory
    
    memory = auto_memory()
    # That's it. Memory is now active and bootstrapped.

Or from CLI:
    python memory_integration.py init "My Project"
    python memory_integration.py status
    python memory_integration.py demo
"""

import sys
import os
import json
from pathlib import Path
from typing import Optional

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent))
from memory_manager import AgentMemoryInterface, MemoryStore, PHASE_ORDER


def find_project_root(start: Optional[str] = None) -> Path:
    """Walk up from start directory to find project root.
    
    Looks for markers: .git, pyproject.toml, package.json, Cargo.toml,
    go.mod, .memory (already initialized)
    """
    markers = [".git", "pyproject.toml", "package.json", "Cargo.toml", "go.mod", ".memory"]
    current = Path(start or os.getcwd()).resolve()
    
    while current != current.parent:
        for marker in markers:
            if (current / marker).exists():
                return current
        current = current.parent
    
    # Fallback to cwd
    return Path(os.getcwd()).resolve()


def auto_memory(
    root: Optional[str] = None,
    project_name: Optional[str] = None,
    agent_name: str = "default",
    auto_session: bool = True,
) -> AgentMemoryInterface:
    """Automatic memory setup. Handles everything:
    
    1. Finds project root
    2. Initializes memory if needed
    3. Starts a session (optional)
    4. Returns ready-to-use interface
    
    Args:
        root: Override memory root path (default: auto-detect)
        project_name: Name for new projects (default: directory name)
        agent_name: Name for this agent's session
        auto_session: Automatically start a session
    
    Returns:
        Configured AgentMemoryInterface
    """
    if root:
        memory_root = Path(root)
    else:
        project_root = find_project_root()
        memory_root = project_root / ".memory"
    
    memory = AgentMemoryInterface(str(memory_root))
    
    # Initialize if new
    if not (memory_root / "manifest.json").exists():
        name = project_name or memory_root.parent.name
        memory.initialize_project(name)
        print(f"🧠 Memory system initialized: {name}")
    
    if auto_session:
        session_id = memory.begin_session(agent_name)
        print(f"📎 Session started: {session_id}")
    
    return memory


def generate_gitignore_entry() -> str:
    """Generate .gitignore entry for memory system.
    
    Memory files should typically be committed (they're project knowledge),
    but session files should be ignored.
    """
    return """
# Memory System
.memory/sessions/
"""


def generate_system_prompt_fragment(memory_root: str = ".memory") -> str:
    """Generate system prompt text that tells an agent how to use the memory system.
    
    Include this in your agent's system prompt to make it memory-aware.
    """
    return f"""
## Memory System

This project has an autonomous memory system at `{memory_root}/`.

### On startup:
1. Read `{memory_root}/BOOTSTRAP.md` for full project context
2. Start a session before doing any work
3. Read only the specific files referenced in the bootstrap

### During work:
- Note discoveries as you make them (insights, decisions, constraints)
- Every discovery must have a context direction and phase
- Link discoveries to the goal you're working on

### On completion:
- Extract skills from completed goals (reusable methods/patterns)
- End your session

### Key files:
- `{memory_root}/BOOTSTRAP.md` — Start here (human-readable overview)
- `{memory_root}/manifest.json` — Machine-readable index of everything
- `{memory_root}/goals/` — Active and completed goals
- `{memory_root}/skills/` — Reusable capabilities from completed work
- `{memory_root}/discoveries/` — Contextual notes and insights

### Python API:
```python
from memory_integration import auto_memory
memory = auto_memory(agent_name="your-agent-type")

# Read bootstrap
context = memory.bootstrap()

# Note a discovery
memory.note("Found that X requires Y", direction="executing", tags=["arch"])

# Set a goal
goal = memory.set_goal(
    title="Implement caching",
    description="Add Redis caching layer",
    group="infrastructure",
    intended_effect="Reduce response times below 50ms",
)

# Complete a goal with skill extraction
memory.finish_goal(goal["id"], "Done", skills=[...])

# End session
memory.end_session()
```
"""


# ─── Project Templates ────────────────────────────────────────────────────────

def setup_for_python_project(project_root: str, project_name: str):
    """Full setup for a Python project."""
    root = Path(project_root)
    memory_root = root / ".memory"
    
    # Initialize memory
    memory = auto_memory(str(memory_root), project_name, auto_session=False)
    
    # Add to .gitignore
    gitignore = root / ".gitignore"
    entry = generate_gitignore_entry()
    if gitignore.exists():
        content = gitignore.read_text()
        if ".memory/sessions/" not in content:
            with open(gitignore, "a") as f:
                f.write(entry)
    else:
        gitignore.write_text(entry)
    
    print(f"✅ Memory system ready for Python project: {project_name}")
    print(f"   Add to your agent: from memory_integration import auto_memory")


def setup_for_node_project(project_root: str, project_name: str):
    """Full setup for a Node.js project."""
    root = Path(project_root)
    memory_root = root / ".memory"
    
    # Initialize memory
    memory = auto_memory(str(memory_root), project_name, auto_session=False)
    
    # Add to .gitignore
    gitignore = root / ".gitignore"
    entry = generate_gitignore_entry()
    if gitignore.exists():
        content = gitignore.read_text()
        if ".memory/sessions/" not in content:
            with open(gitignore, "a") as f:
                f.write(entry)
    
    # Create JS wrapper
    js_wrapper = root / "memory.mjs"
    js_wrapper.write_text("""
// Memory System — JavaScript wrapper
// Uses the Python memory manager via subprocess

import { execSync } from 'child_process';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';

const MEMORY_ROOT = '.memory';

export function bootstrap() {
  const path = join(MEMORY_ROOT, 'BOOTSTRAP.md');
  if (existsSync(path)) {
    return readFileSync(path, 'utf-8');
  }
  return 'No bootstrap found. Run: python memory_integration.py init "Project Name"';
}

export function readManifest() {
  const path = join(MEMORY_ROOT, 'manifest.json');
  if (existsSync(path)) {
    return JSON.parse(readFileSync(path, 'utf-8'));
  }
  return null;
}

export function readEntry(category, entryId) {
  const path = join(MEMORY_ROOT, category, `${entryId}.json`);
  if (existsSync(path)) {
    return JSON.parse(readFileSync(path, 'utf-8'));
  }
  return null;
}

export function getSkillsForPhase(phase) {
  const manifest = readManifest();
  if (!manifest) return [];
  
  return Object.entries(manifest.index.skills || {})
    .filter(([_, meta]) => meta.phase === phase)
    .map(([id, meta]) => ({
      ...meta,
      id,
      full: readEntry('skills', id)
    }));
}
""")
    
    print(f"✅ Memory system ready for Node.js project: {project_name}")
    print(f"   Import: import {{ bootstrap }} from './memory.mjs'")


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Memory System Integration")
    sub = parser.add_subparsers(dest="command")
    
    # init
    init_cmd = sub.add_parser("init", help="Initialize memory for current project")
    init_cmd.add_argument("name", help="Project name")
    init_cmd.add_argument("--type", choices=["python", "node", "generic"], default="generic")
    
    # status
    sub.add_parser("status", help="Show memory status")
    
    # prompt
    sub.add_parser("prompt", help="Generate system prompt fragment")
    
    # demo
    sub.add_parser("demo", help="Run a demo showing how the system works")
    
    args = parser.parse_args()
    
    if args.command == "init":
        cwd = os.getcwd()
        if args.type == "python":
            setup_for_python_project(cwd, args.name)
        elif args.type == "node":
            setup_for_node_project(cwd, args.name)
        else:
            memory = auto_memory(project_name=args.name, auto_session=False)
            print(f"✅ Memory system initialized: {args.name}")
    
    elif args.command == "status":
        memory = AgentMemoryInterface()
        m = memory.store.manifest
        print(f"\n🧠 Memory Status")
        print(f"   Project: {m.get('project_name', 'N/A')}")
        print(f"   Phase:   {m['current_phase']}")
        print(f"   Sessions active: {len(m['active_sessions'])}")
        print(f"\n   📊 Stats:")
        for k, v in m["stats"].items():
            print(f"      {k}: {v}")
        print(f"\n   📁 Phase Progression:")
        for phase, status in m["phase_progression"].items():
            icon = {"completed": "✅", "active": "🔄", "pending": "⏳"}.get(status, "❓")
            print(f"      {icon} {phase}: {status}")
    
    elif args.command == "prompt":
        print(generate_system_prompt_fragment())
    
    elif args.command == "demo":
        run_demo()
    
    else:
        parser.print_help()


def run_demo():
    """Interactive demo that shows the system in action."""
    import tempfile
    
    print("\n" + "="*60)
    print("🧠 MEMORY SYSTEM DEMO")
    print("="*60)
    
    # Use temp directory
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_root = os.path.join(tmpdir, ".memory")
        
        # Step 1: Initialize
        print("\n📌 Step 1: Initialize project")
        memory = AgentMemoryInterface(memory_root)
        memory.initialize_project("Demo Project")
        
        # Step 2: Start session
        print("\n📌 Step 2: Start agent session")
        session = memory.begin_session("demo-agent")
        print(f"   Session: {session}")
        
        # Step 3: Set goals
        print("\n📌 Step 3: Set goals for 'crawl' phase")
        goal1 = memory.set_goal(
            title="Setup database schema",
            description="Create initial PostgreSQL schema with users and projects tables",
            group="foundation",
            intended_effect="Provides data persistence layer",
            enables_existing="Nothing yet — this is foundational",
            opens_doors=["API endpoints", "Authentication", "Reporting"],
            criteria=["Tables created", "Migrations work", "Tests pass"],
        )
        print(f"   Goal 1: {goal1['id']} — {goal1['title']}")
        
        goal2 = memory.set_goal(
            title="Implement basic API",
            description="REST API with CRUD operations for users and projects",
            group="foundation",
            intended_effect="Exposes data layer to frontend",
            enables_existing="Database can now be accessed externally",
            opens_doors=["Frontend integration", "Mobile app", "Webhooks"],
            depends_on=[goal1["id"]],
            criteria=["All CRUD endpoints work", "Error handling in place"],
        )
        print(f"   Goal 2: {goal2['id']} — {goal2['title']}")
        
        # Step 4: Make discoveries
        print("\n📌 Step 4: Note discoveries during work")
        disc1 = memory.note(
            content="PostgreSQL's JSONB columns work well for flexible project metadata without schema changes",
            title="JSONB for flexible metadata",
            direction="executing",
            goal_id=goal1["id"],
            plan_connection="This means we don't need a separate key-value store later",
            enables=["Dynamic project fields", "Plugin system"],
            tags=["database", "architecture", "postgresql"],
        )
        print(f"   Discovery: {disc1['id']} — {disc1['title']}")
        
        # Step 5: Complete goal with skill extraction
        print("\n📌 Step 5: Complete goal and extract skills")
        acmp = memory.finish_goal(
            goal1["id"],
            summary="Database schema implemented with users, projects, and JSONB metadata columns. Migrations tested.",
            skills=[{
                "name": "pg-migration-pattern",
                "description": "How to create and run database migrations in this project",
                "method": "Use alembic with our custom env.py. Templates in db/migrations/",
                "phase_origin": "crawl",
                "from_accomplishment": "",
                "usage_context": "Whenever the schema needs to change",
                "dependencies": ["PostgreSQL running", "DATABASE_URL env var"],
                "examples": ["alembic revision --autogenerate -m 'add table'", "alembic upgrade head"],
            }]
        )
        print(f"   Accomplishment: {acmp['id']}")
        
        # Step 6: Show bootstrap
        print("\n📌 Step 6: Bootstrap file (what a new agent reads)")
        print("-" * 40)
        print(memory.bootstrap())
        print("-" * 40)
        
        # Step 7: Query
        print("\n📌 Step 7: Query — find active goals")
        active = memory.find(category="goals", status="active")
        for g in active:
            print(f"   Active: {g['id']} — {g['title']}")
        
        # Step 8: End session
        print("\n📌 Step 8: End session")
        memory.end_session()
        
        print("\n✅ Demo complete!")
        print("   The bootstrap file is the key — a new agent reads it and instantly")
        print("   knows the project state, active goals, and available skills.")


if __name__ == "__main__":
    main()
