# CIRCUIT BREAKER LOG

## REGLER:
Reviewer inkrementerar `Attempts` varje gång en task skickas TILLBAKA.
**Attempts >= 3** → Status i task_board → `BLOCKED_HUMAN` → SYSTEMET STOPPAR.

## AKTIVA ÄRENDEN

| Task ID | Agent | Attempts | Senaste felmeddelande |
|---------|-------|----------|----------------------|
| — | — | 0 | System initierat |

## HISTORIK
<!-- Flytta resolved ärenden hit -->
