# 🧠 Autonomous Memory System for LLM Agents

A framework that gives any no-context LLM agent instant project understanding through a single bootstrap file, session-isolated operations, and hierarchical goal tracking with bidirectional phase references.

## The Problem

When an LLM agent starts a new session, it has zero context. It doesn't know:
- What the project is
- What has been done
- What needs to happen next
- What patterns and skills have been established
- What other agents are currently doing

Without a memory system, agents waste tokens re-discovering context, make conflicting decisions, and lose hard-won insights between sessions.

## The Solution

This framework creates a **self-maintaining memory layer** with three core properties:

1. **Bootstrap-first**: A cold-start agent reads ONE file (`BOOTSTRAP.md`) and understands everything
2. **Context-directed**: Every entry knows *why* it exists, not just *what* it contains
3. **Phase-progressive**: Work flows through maturity phases, with skills extracted at each stage for reuse

## Quick Start

```python
from memory_integration import auto_memory

# Initialize (auto-detects project root)
memory = auto_memory(project_name="My Project", agent_name="coding-agent")

# Read bootstrap (cold-start)
context = memory.bootstrap()

# Set a goal
goal = memory.set_goal(
    title="Implement user auth",
    description="JWT-based authentication with refresh tokens",
    group="foundation",
    intended_effect="Enables all user-facing features",
    enables_existing="API endpoints can now be secured",
    opens_doors=["Role-based access", "SSO integration", "Audit logging"],
    criteria=["Login/logout works", "Tokens refresh correctly", "Tests pass"]
)

# Note discoveries as you work
memory.note(
    "bcrypt is already installed — using it for password hashing",
    direction="executing",
    goal_id=goal["id"],
    tags=["auth", "security"]
)

# Complete goal, extract reusable skills
memory.finish_goal(goal["id"], "Auth implemented with JWT + refresh tokens", skills=[
    {
        "name": "jwt-auth-pattern",
        "description": "JWT auth with refresh tokens",
        "method": "See src/auth/ — uses middleware pattern",
        "phase_origin": "crawl",
        "from_accomplishment": "",
        "usage_context": "Adding auth to new endpoints",
        "dependencies": ["JWT_SECRET env var", "bcrypt"],
        "examples": ["@require_auth decorator on routes"]
    }
])

# End session
memory.end_session()
```

## Architecture

```
.memory/
├── BOOTSTRAP.md          ← Cold-start: agents read ONLY this
├── manifest.json         ← Machine-readable index of everything
├── sessions/             ← Isolated per session-ID (gitignored)
├── discoveries/          ← Contextual notes and insights
├── goals/                ← Active and completed goals
├── accomplishments/      ← Completed goals with full traceability
├── skills/               ← Extracted reusable methods/patterns
└── phases/               ← Phase summaries with cross-references
```

### Entry Types

| Type | Purpose | Key Property |
|------|---------|-------------|
| **Discovery** | Context-directed insight | Knows *why* it was noted (planning/executing/reviewing/debugging) |
| **Goal** | Objective with full connections | Knows what it enables, depends on, and opens doors to |
| **Accomplishment** | Completed goal with timeline | Quick-reference to what/why/enables/unlocks |
| **Skill** | Reusable method from completed work | The "fast path" — skip phase history, use the capability |
| **Phase** | Phase summary with navigation | Links forward and backward through the progression |

### Phase Progression

| Phase | Metaphor | Meaning |
|-------|----------|---------|
| crawl | Ål | Proving concepts, laying foundations |
| creep | Kräla | Basic integration, early connections |
| walk  | Gå | Functional system, reliable patterns |
| run   | Springa | Optimization, scaling, advanced features |
| fly   | Flyga | Autonomous, self-improving |

## How It Works

### 1. Bootstrap (Cold Start)
```
New Agent → Reads BOOTSTRAP.md → Knows:
  - Current phase
  - Active goals (with file paths)
  - Available skills (the fast path)
  - Recent accomplishments
  - Active sessions (coordination)
```

### 2. Session Isolation
Each agent gets a unique session ID (`20260311-a3f8c1b2`), preventing collisions when multiple agents work simultaneously.

### 3. Bidirectional References
Every entry links both forward and backward:
```
Goal "Implement caching"
  ├── depends_on: ["goal: Setup database"]
  ├── intended_effect: "Reduce response times"
  ├── enables_existing: "API endpoints become faster"
  └── opens_doors: ["Real-time features", "Mobile support"]
```

### 4. Skill Extraction (The Fast Path)
When a phase completes, reusable skills are extracted. Future agents load *skills* instead of replaying entire phase histories.

```
Phase "crawl" completed → Skills extracted:
  - pg-migration-pattern: "How to run DB migrations"
  - jwt-auth-pattern: "How to add auth to endpoints"

New agent needs auth? → Reads skill file → Done.
No need to read the entire crawl phase history.
```

## CLI Usage

```bash
# Initialize
python memory_integration.py init "My Project"

# Check status
python memory_integration.py status

# Run interactive demo
python memory_integration.py demo

# Generate system prompt fragment
python memory_integration.py prompt
```

## Integration

### Add to Agent System Prompt
```python
from memory_integration import generate_system_prompt_fragment
prompt_addition = generate_system_prompt_fragment()
# Append to your agent's system prompt
```

### Python Projects
```bash
python memory_integration.py init "My Project" --type python
```

### Node.js Projects
```bash
python memory_integration.py init "My Project" --type node
# Creates memory.mjs wrapper
```

### .gitignore
Sessions are gitignored (they're per-agent). Everything else should be committed — it's project knowledge.

## Design Principles

1. **Minimum viable context**: An agent never reads more than it needs
2. **Never search in a haystack**: The bootstrap file has shortcuts to everything
3. **Autonomy after activation**: The system works without human intervention
4. **Phase isolation with skill bridging**: Past phases are accessed through skills, not replay
5. **Collision safety**: Session IDs prevent multi-agent conflicts
6. **Bidirectional navigation**: Every entry can be reached from its connections

## Files

| File | Purpose |
|------|---------|
| `memory_manager.py` | Core engine — data structures, store, bootstrap generation |
| `memory_integration.py` | Drop-in setup — auto-detection, project templates, CLI |
| `AGENT_PROTOCOL.md` | Agent instructions — how to use the system autonomously |
| `README.md` | This file |
