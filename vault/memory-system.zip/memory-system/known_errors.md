# KNOWN ERRORS & FIXES

> Kolla här FÖRST när fel uppstår. Finns felet? → Applicera fix direkt.
> Finns inte? → Felsök, fixa, LÄGG TILL här efteråt.

## Format:
```
### [Felmeddelande / mönster]
Kontext: [När detta uppstår]
Fix: [Exakt vad som ska göras]
Tillagt: [Datum] av [Agent]
```

## Kända fel:
<!-- Append-only. Alla agenter bidrar. -->
