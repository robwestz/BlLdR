# Autonomous Workspace Bootstrap
**Status**: krypa
**Started**: 2026-03-17
**Last updated**: 2026-03-17
**Lead agent**: orchestrator

## Purpose
Set up the foundational infrastructure for NOMO's autonomous agent workspace. This is the first project — everything else depends on this being solid.

## Current Phase: krypa

### Krypa (Foundation) — in-progress
**What**: Core workspace structure, agent definitions, CLAUDE.md, hooks, memory system
**Why**: Without this foundation, no autonomous work is possible. The workspace must have clear rules, agent roles, and a memory system before any real work begins.
**Depends on**: nothing (this is the root)
**Required by**: ALL future projects
**Key decisions**:
- Claude Agent SDK (Python) as runtime, not OpenClaw (security concerns, not our stack)
- Mac as local agent host, DigitalOcean for production
- Krypa-gå-springa memory pattern for cross-session continuity
- Opus 4.6 for orchestration, Sonnet 4.6 for building, Haiku 4.5 for memory
- HR-agent pattern: new agents created on demand, never reuse a generalist

### Gå (Extension) — planned
**What**: Agent SDK orchestrator script, MCP server integrations (Ahrefs, Memory Architect), Open Brain setup (Supabase + vector search)
**Why**: Extends krypa from "structure exists" to "agents can actually run tasks and persist memory across sessions"
**Depends on**: krypa
**Required by**: springa phase, all SEO projects

### Springa (Full capability) — planned
**What**: Full autonomous operation — scheduled agents, multi-session campaigns, self-creating agents, commercial-ready tooling
**Why**: The goal state — minimal human involvement, maximum autonomous output
**Depends on**: krypa + gå

## Session Log
| Date | Agent | What was done | Next step |
|------|-------|---------------|-----------|
| 2026-03-17 | claude.ai (manual) | Created workspace structure, 7 agents, CLAUDE.md, hooks, memory system | Install on Mac, run first Agent SDK session |

## Blockers
- None currently. Next step is purely execution.

## Files Created
- `CLAUDE.md` — Project brain
- `.claude/agents/orchestrator.md` — Lead agent
- `.claude/agents/builder.md` — Code generator
- `.claude/agents/seo-ops.md` — SEO specialist
- `.claude/agents/content-writer.md` — Content production
- `.claude/agents/qa-gate.md` — Quality assurance
- `.claude/agents/hr-agent.md` — Agent factory
- `.claude/agents/memory-keeper.md` — Context maintenance
- `.claude/settings.json` — Hooks (branch protection, dangerous cmd blocking, auto-format, session logging)
- `memory/active-projects/workspace-bootstrap.md` — This file
