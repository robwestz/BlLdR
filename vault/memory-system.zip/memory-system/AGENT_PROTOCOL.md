# Agent Memory Protocol
## Autonomous Operation Guide

This document defines how an LLM agent should interact with the memory system.
**Read this once, then follow it automatically.**

---

## Cold Start Procedure

When you are a new agent with no context:

1. **READ** `.memory/BOOTSTRAP.md` — this is your ONLY required read
2. **START** a session: call `begin_session("your-agent-type")`
3. **IDENTIFY** what you need to do from the bootstrap's active goals
4. **LOAD** only the context you need (goal file + its dependencies)
5. **WORK** — noting discoveries as you go

**Never read all files. Never search through directories. The bootstrap has shortcuts to everything.**

---

## During Work

### When to Write a Discovery
- You learned something that would help a future agent
- You found a dependency or constraint not documented
- You made a decision that has implications
- Something didn't work as expected
- You found a better approach than what was planned

### How to Write a Discovery
```python
memory.note(
    content="The database schema requires foreign key indexes for the join queries to perform acceptably",
    title="FK indexes required for join performance",
    direction="executing",        # planning | executing | reviewing | debugging
    goal_id="goal-a3f8-1b2c3d",  # which goal this relates to
    plan_connection="This affects all data layer goals — queries will time out without it",
    enables=["Fast reporting queries", "Real-time dashboard"],
    tags=["database", "performance", "architecture"]
)
```

### Context Direction Values
- **planning** — Noted while planning; helps future planning agents
- **executing** — Noted while doing; helps future execution agents  
- **reviewing** — Noted while reviewing work; helps quality agents
- **debugging** — Noted while fixing issues; helps future debugging agents

---

## Goal Management

### Setting Goals
Every goal must answer:
1. **What** does this accomplish? (`description`)
2. **Why** does this matter? (`intended_effect`)
3. **What** does this enable for what already exists? (`enables_existing`)
4. **What doors** does this open? (`opens_doors`)
5. **What** must be done first? (`depends_on`)
6. **How** do we know it's done? (`criteria`)

### Goal Groups
Goals within a phase are grouped. Groups represent logical units:
- `foundation` — Base infrastructure that other things depend on
- `integration` — Connecting components together  
- `validation` — Testing and verifying
- `optimization` — Making things better
- Custom groups as needed

### Completing Goals
When you finish a goal, always extract skills if applicable:
```python
memory.finish_goal(
    goal_id="goal-a3f8-1b2c3d",
    summary="Implemented the caching layer with Redis, achieving <50ms response times",
    skills=[
        {
            "name": "redis-cache-pattern",
            "description": "How to implement Redis caching in this project",
            "method": "See src/cache/redis_client.py — uses the wrapper pattern with TTL groups",
            "phase_origin": "walk",
            "from_accomplishment": "",  # Filled automatically
            "usage_context": "Whenever a new endpoint needs caching",
            "dependencies": ["Redis server running", "CACHE_URL env var set"],
            "examples": ["See tests/test_cache.py for usage examples"]
        }
    ]
)
```

---

## Phase Transitions

Phases represent maturity stages. The standard progression:

| Phase | Metaphor | Meaning |
|-------|----------|---------|
| crawl | Ål (eel) | Proving concepts, laying foundations |
| creep | Kräla | Basic integration, early connections |
| walk  | Gå | Functional system, reliable patterns |
| run   | Springa | Optimization, scaling, advanced features |
| fly   | Flyga | Autonomous, self-improving |

### When to Complete a Phase
A phase is complete when:
- All its goals are accomplished
- Skills have been extracted from accomplishments
- The phase summary documents key decisions
- The next phase's prerequisites are met

### Phase Completion
```python
memory.store.complete_phase(
    session_id=memory.session_id,
    phase_name="crawl",
    objectives="Prove that the core architecture works",
    goals_included=["goal-xxx", "goal-yyy"],
    accomplishments=["acmp-xxx", "acmp-yyy"],
    skills_produced=["skll-xxx"],
    key_decisions=["Chose PostgreSQL over MongoDB", "Event-driven over polling"],
    enables_next_phase="Integration with external services",
    depends_on_phase=None  # First phase
)
```

---

## Multi-Agent Coordination

### Session Isolation
- Every agent gets a unique session ID
- All entries are tagged with their session ID
- The bootstrap file shows active sessions

### Avoiding Conflicts
- Check `BOOTSTRAP.md` for active sessions before starting
- Don't modify entries from other sessions
- If you need to build on another session's discovery, create a new one with `depends_on` pointing to the original
- Goal status changes are the one exception — if a goal is completed, mark it regardless of session

### Parallel Work
- Different agents can work on different goals simultaneously
- Use goal groups to divide work: Agent A takes `foundation`, Agent B takes `integration`
- Session IDs in entries make it traceable who did what

---

## The Fast Path

When you need to USE capabilities from a completed phase (not understand it):

1. Look at the bootstrap file's "Available Skills" section
2. Load only the specific skill file(s) you need
3. Follow the skill's `method` and `dependencies`
4. You now have the capability without reading the entire phase history

**This is the whole point.** A new agent working on phase "run" doesn't need to replay phases "crawl" through "walk" — it loads the skills those phases produced.

---

## Rules

1. **Always start with bootstrap** — never explore blindly
2. **Note discoveries as they happen** — don't batch them
3. **Every goal has context** — naked "do X" goals are not allowed
4. **Extract skills on completion** — this is what makes phases reusable
5. **Keep entries atomic** — one insight per discovery, one objective per goal
6. **Use tags consistently** — they're the search mechanism
7. **Don't modify others' entries** — create new ones that reference them
8. **End your session** — always, even on failure
