#!/usr/bin/env python3
"""
Autonomous Memory System for LLM Agents
========================================
A framework that gives any no-context agent instant project understanding
through a bootstrap file, session-isolated operations, and hierarchical
goal tracking with bidirectional phase references.

Core design principles:
  1. Bootstrap-first: Cold-start agents read ONE file to understand everything
  2. Session-isolated: Unique IDs prevent collisions in multi-agent scenarios
  3. Context-directed: Every entry knows WHY it exists, not just WHAT it contains
  4. Phase-progressive: Goals flow through phases (crawl → walk → run)
  5. Bidirectional: Every entry links forward (enables) and backward (depends on)
  6. Skill-extracting: Completed phases distill reusable skills/methods
"""

import json
import os
import uuid
import hashlib
import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any


# ─── Configuration ────────────────────────────────────────────────────────────

DEFAULT_MEMORY_ROOT = ".memory"
MANIFEST_FILE = "manifest.json"
BOOTSTRAP_FILE = "BOOTSTRAP.md"

PHASE_ORDER = [
    "crawl",    # ål – fundamentals, proving concepts
    "creep",    # kräla – basic integration, early structure
    "walk",     # gå – functional system, reliable patterns
    "run",      # springa – optimization, scaling, advanced features
    "fly",      # flyga – autonomous, self-improving (optional stretch)
]


# ─── Session Management ──────────────────────────────────────────────────────

def generate_session_id() -> str:
    """Generate a unique, collision-safe session ID.
    
    Format: {timestamp_short}-{random_hex8}
    Example: 20260311-a3f8c1b2
    """
    ts = datetime.datetime.now().strftime("%Y%m%d")
    rand = uuid.uuid4().hex[:8]
    return f"{ts}-{rand}"


def generate_entry_id(session_id: str, category: str) -> str:
    """Generate a unique entry ID scoped to session and category.
    
    Format: {category_prefix}-{session_short}-{random_hex6}
    Example: disc-a3f8-1b2c3d
    """
    prefix_map = {
        "discovery": "disc",
        "goal": "goal",
        "accomplishment": "acmp",
        "skill": "skll",
        "phase": "phse",
    }
    prefix = prefix_map.get(category, category[:4])
    session_short = session_id.split("-")[-1][:4]
    rand = uuid.uuid4().hex[:6]
    return f"{prefix}-{session_short}-{rand}"


# ─── Core Data Structures ────────────────────────────────────────────────────

def create_discovery(
    session_id: str,
    title: str,
    content: str,
    context_direction: str,
    phase: str,
    relates_to_goal: Optional[str] = None,
    connects_to_plan: Optional[str] = None,
    enables_future: Optional[List[str]] = None,
    depends_on: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Create a context-directed discovery entry.
    
    A discovery is a piece of knowledge gained during work. It always knows:
    - WHY it was noted (context_direction)
    - WHAT phase it belongs to
    - HOW it connects to the larger plan
    - WHAT it enables for the future
    
    Args:
        session_id: Active session identifier
        title: Short, searchable title
        content: The actual discovery content
        context_direction: One of 'planning', 'executing', 'reviewing', 'debugging'
                          — tells future agents what mode produced this insight
        phase: Which phase this belongs to (e.g., 'crawl', 'walk')
        relates_to_goal: ID of the goal this discovery supports
        connects_to_plan: How this fits the larger project plan
        enables_future: List of things this discovery makes possible
        depends_on: List of entry IDs this builds upon
        tags: Searchable tags for quick filtering
    """
    entry_id = generate_entry_id(session_id, "discovery")
    return {
        "id": entry_id,
        "type": "discovery",
        "session_id": session_id,
        "timestamp": datetime.datetime.now().isoformat(),
        "title": title,
        "content": content,
        "context": {
            "direction": context_direction,
            "phase": phase,
            "relates_to_goal": relates_to_goal,
            "connects_to_plan": connects_to_plan,
            "enables_future": enables_future or [],
            "depends_on": depends_on or [],
        },
        "tags": tags or [],
        "superseded_by": None,  # Set if a newer discovery replaces this
    }


def create_goal(
    session_id: str,
    title: str,
    description: str,
    phase: str,
    group: str,
    intended_effect: str,
    enables_for_existing: str,
    opens_doors_to: List[str],
    depends_on_goals: Optional[List[str]] = None,
    acceptance_criteria: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Create a goal with full context about its purpose and connections.
    
    Goals are always grouped by phase and know:
    - What effect they're intended to have on the repo
    - What they enable for existing functionality
    - What future doors they open (planned or unplanned)
    
    Args:
        session_id: Active session identifier
        title: Short goal title
        description: What needs to be accomplished
        phase: Phase this goal belongs to
        group: Sub-group within phase (e.g., 'foundation', 'integration')
        intended_effect: What this goal does to/for the project
        enables_for_existing: What this unlocks for current functionality
        opens_doors_to: Future possibilities this creates
        depends_on_goals: Goal IDs that must be completed first
        acceptance_criteria: How we know this goal is done
    """
    entry_id = generate_entry_id(session_id, "goal")
    return {
        "id": entry_id,
        "type": "goal",
        "session_id": session_id,
        "timestamp": datetime.datetime.now().isoformat(),
        "title": title,
        "description": description,
        "status": "active",  # active | in_progress | blocked | completed
        "phase": phase,
        "group": group,
        "connections": {
            "intended_effect": intended_effect,
            "enables_for_existing": enables_for_existing,
            "opens_doors_to": opens_doors_to,
            "depends_on_goals": depends_on_goals or [],
        },
        "acceptance_criteria": acceptance_criteria or [],
        "discoveries": [],      # IDs of discoveries made while pursuing this
        "skills_produced": [],   # IDs of skills extracted upon completion
        "completed_at": None,
        "accomplishment_id": None,  # Set when moved to accomplishments
    }


def complete_goal(goal: Dict, summary: str, skills_extracted: List[str]) -> Dict[str, Any]:
    """Move a goal to accomplishment status.
    
    Creates an accomplishment entry with full traceability:
    - When the original goal was created and completed
    - What was learned (linked discoveries)
    - What skills/methods emerged
    - Quick-reference back to the phase context
    """
    acmp_id = generate_entry_id(goal["session_id"], "accomplishment")
    
    accomplishment = {
        "id": acmp_id,
        "type": "accomplishment",
        "original_goal_id": goal["id"],
        "session_id": goal["session_id"],
        "timestamp": datetime.datetime.now().isoformat(),
        "title": goal["title"],
        "summary": summary,
        "phase": goal["phase"],
        "group": goal["group"],
        "timeline": {
            "goal_created": goal["timestamp"],
            "goal_completed": datetime.datetime.now().isoformat(),
        },
        "connections": goal["connections"],
        "discoveries_made": goal["discoveries"],
        "skills_extracted": skills_extracted,
        "quick_reference": {
            "what": goal["description"],
            "why": goal["connections"]["intended_effect"],
            "enables": goal["connections"]["enables_for_existing"],
            "unlocks": goal["connections"]["opens_doors_to"],
        },
    }
    
    # Update the original goal
    goal["status"] = "completed"
    goal["completed_at"] = datetime.datetime.now().isoformat()
    goal["accomplishment_id"] = acmp_id
    goal["skills_produced"] = skills_extracted
    
    return accomplishment


def create_skill(
    session_id: str,
    name: str,
    description: str,
    method: str,
    phase_origin: str,
    from_accomplishment: str,
    usage_context: str,
    dependencies: Optional[List[str]] = None,
    examples: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Create a reusable skill/method extracted from completed work.
    
    Skills are the 'fast path' — when an agent needs capabilities from
    a completed phase, it reads skills instead of replaying the entire phase.
    
    Args:
        name: Skill identifier (e.g., 'database-migration')
        description: What this skill does
        method: Step-by-step method or code reference
        phase_origin: Which phase this was extracted from
        from_accomplishment: Accomplishment ID that produced this
        usage_context: When and how to apply this skill
        dependencies: What must be in place to use this skill
        examples: Example invocations or applications
    """
    entry_id = generate_entry_id(session_id, "skill")
    return {
        "id": entry_id,
        "type": "skill",
        "session_id": session_id,
        "timestamp": datetime.datetime.now().isoformat(),
        "name": name,
        "description": description,
        "method": method,
        "origin": {
            "phase": phase_origin,
            "accomplishment_id": from_accomplishment,
        },
        "usage_context": usage_context,
        "dependencies": dependencies or [],
        "examples": examples or [],
    }


def create_phase_summary(
    session_id: str,
    phase_name: str,
    objectives: str,
    goals_included: List[str],
    accomplishments: List[str],
    skills_produced: List[str],
    key_decisions: List[str],
    enables_next_phase: str,
    depends_on_phase: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a phase summary — the high-level view of a completed phase.
    
    Phase summaries are the bridge between phases. They answer:
    - What was this phase about?
    - What did we accomplish?
    - What skills emerged?
    - What does the next phase need from us?
    """
    entry_id = generate_entry_id(session_id, "phase")
    return {
        "id": entry_id,
        "type": "phase",
        "session_id": session_id,
        "timestamp": datetime.datetime.now().isoformat(),
        "name": phase_name,
        "order": PHASE_ORDER.index(phase_name) if phase_name in PHASE_ORDER else -1,
        "status": "completed",
        "objectives": objectives,
        "goals_included": goals_included,
        "accomplishments": accomplishments,
        "skills_produced": skills_produced,
        "key_decisions": key_decisions,
        "navigation": {
            "depends_on_phase": depends_on_phase,
            "enables_next_phase": enables_next_phase,
            "next_phase": _get_next_phase(phase_name),
            "prev_phase": _get_prev_phase(phase_name),
        },
    }


def _get_next_phase(current: str) -> Optional[str]:
    try:
        idx = PHASE_ORDER.index(current)
        return PHASE_ORDER[idx + 1] if idx + 1 < len(PHASE_ORDER) else None
    except ValueError:
        return None


def _get_prev_phase(current: str) -> Optional[str]:
    try:
        idx = PHASE_ORDER.index(current)
        return PHASE_ORDER[idx - 1] if idx > 0 else None
    except ValueError:
        return None


# ─── Memory Store ─────────────────────────────────────────────────────────────

class MemoryStore:
    """Persistent memory store with atomic operations and manifest tracking.
    
    The store manages all memory entries and maintains a manifest that
    serves as the machine-readable index. The manifest is always kept
    in sync with the individual entry files.
    """
    
    def __init__(self, root: str = DEFAULT_MEMORY_ROOT):
        self.root = Path(root)
        self.manifest_path = self.root / MANIFEST_FILE
        self.bootstrap_path = self.root / BOOTSTRAP_FILE
        self._ensure_structure()
        self.manifest = self._load_manifest()
    
    def _ensure_structure(self):
        """Create directory structure if it doesn't exist."""
        dirs = [
            self.root,
            self.root / "sessions",
            self.root / "discoveries",
            self.root / "goals",
            self.root / "accomplishments",
            self.root / "skills",
            self.root / "phases",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
    
    def _load_manifest(self) -> Dict:
        """Load or initialize the manifest."""
        if self.manifest_path.exists():
            with open(self.manifest_path) as f:
                return json.load(f)
        return {
            "version": "1.0.0",
            "created": datetime.datetime.now().isoformat(),
            "last_updated": datetime.datetime.now().isoformat(),
            "project_name": "",
            "current_phase": PHASE_ORDER[0],
            "active_sessions": [],
            "index": {
                "discoveries": {},
                "goals": {},
                "accomplishments": {},
                "skills": {},
                "phases": {},
            },
            "phase_progression": {p: "pending" for p in PHASE_ORDER},
            "stats": {
                "total_discoveries": 0,
                "total_goals": 0,
                "total_accomplishments": 0,
                "total_skills": 0,
                "completed_phases": 0,
            },
        }
    
    def _save_manifest(self):
        """Persist manifest to disk."""
        self.manifest["last_updated"] = datetime.datetime.now().isoformat()
        with open(self.manifest_path, "w") as f:
            json.dump(self.manifest, f, indent=2, ensure_ascii=False)
    
    def _save_entry(self, entry: Dict):
        """Save an individual entry to its category directory."""
        category = entry["type"]
        # Map type to directory
        dir_map = {
            "discovery": "discoveries",
            "goal": "goals",
            "accomplishment": "accomplishments",
            "skill": "skills",
            "phase": "phases",
        }
        directory = self.root / dir_map[category]
        filepath = directory / f"{entry['id']}.json"
        with open(filepath, "w") as f:
            json.dump(entry, f, indent=2, ensure_ascii=False)
        return filepath
    
    def _index_entry(self, entry: Dict):
        """Add entry to manifest index with navigable metadata."""
        category = entry["type"]
        dir_map = {
            "discovery": "discoveries",
            "goal": "goals",
            "accomplishment": "accomplishments",
            "skill": "skills",
            "phase": "phases",
        }
        index_key = dir_map[category]
        
        index_entry = {
            "title": entry.get("title") or entry.get("name", ""),
            "session_id": entry["session_id"],
            "timestamp": entry["timestamp"],
            "phase": entry.get("phase", ""),
        }
        
        # Add type-specific index fields
        if category == "discovery":
            index_entry["direction"] = entry["context"]["direction"]
            index_entry["tags"] = entry.get("tags", [])
            index_entry["phase"] = entry["context"].get("phase", "")
        elif category == "goal":
            index_entry["status"] = entry["status"]
            index_entry["group"] = entry.get("group", "")
        elif category == "accomplishment":
            index_entry["original_goal"] = entry["original_goal_id"]
            index_entry["skills"] = entry["skills_extracted"]
        elif category == "skill":
            index_entry["usage"] = entry["usage_context"]
            index_entry["phase"] = entry.get("origin", {}).get("phase", "")
        elif category == "phase":
            index_entry["status"] = entry["status"]
            index_entry["order"] = entry["order"]
        
        self.manifest["index"][index_key][entry["id"]] = index_entry
        
        # Update stats
        stat_key = f"total_{index_key}"
        if stat_key in self.manifest["stats"]:
            self.manifest["stats"][stat_key] = len(self.manifest["index"][index_key])
    
    # ── Public API ────────────────────────────────────────────────────────
    
    def start_session(self, agent_name: str = "default") -> str:
        """Start a new isolated session. Returns session ID."""
        session_id = generate_session_id()
        session_info = {
            "id": session_id,
            "agent": agent_name,
            "started": datetime.datetime.now().isoformat(),
            "status": "active",
        }
        # Save session file
        session_path = self.root / "sessions" / f"{session_id}.json"
        with open(session_path, "w") as f:
            json.dump(session_info, f, indent=2)
        
        self.manifest["active_sessions"].append(session_id)
        self._save_manifest()
        return session_id
    
    def end_session(self, session_id: str):
        """Mark a session as ended."""
        session_path = self.root / "sessions" / f"{session_id}.json"
        if session_path.exists():
            with open(session_path) as f:
                session = json.load(f)
            session["status"] = "ended"
            session["ended"] = datetime.datetime.now().isoformat()
            with open(session_path, "w") as f:
                json.dump(session, f, indent=2)
        
        if session_id in self.manifest["active_sessions"]:
            self.manifest["active_sessions"].remove(session_id)
        self._save_manifest()
    
    def add_discovery(self, **kwargs) -> Dict:
        """Add a discovery and update all indices."""
        entry = create_discovery(**kwargs)
        self._save_entry(entry)
        self._index_entry(entry)
        self._save_manifest()
        self._regenerate_bootstrap()
        return entry
    
    def add_goal(self, **kwargs) -> Dict:
        """Add a goal and update all indices."""
        entry = create_goal(**kwargs)
        self._save_entry(entry)
        self._index_entry(entry)
        self._save_manifest()
        self._regenerate_bootstrap()
        return entry
    
    def complete_goal_by_id(
        self, goal_id: str, summary: str, skills_extracted: Optional[List[str]] = None
    ) -> Dict:
        """Complete a goal, creating an accomplishment and optional skills."""
        # Load goal
        goal_path = self.root / "goals" / f"{goal_id}.json"
        with open(goal_path) as f:
            goal = json.load(f)
        
        skill_ids = []
        if skills_extracted:
            for skill_data in skills_extracted:
                skill = create_skill(
                    session_id=goal["session_id"],
                    **skill_data,
                )
                self._save_entry(skill)
                self._index_entry(skill)
                skill_ids.append(skill["id"])
        
        accomplishment = complete_goal(goal, summary, skill_ids)
        
        # Save updated goal
        self._save_entry(goal)
        self._index_entry(goal)  # Update index with new status
        
        # Save accomplishment
        self._save_entry(accomplishment)
        self._index_entry(accomplishment)
        
        self._save_manifest()
        self._regenerate_bootstrap()
        return accomplishment
    
    def complete_phase(self, session_id: str, phase_name: str, **kwargs) -> Dict:
        """Complete a phase and create its summary."""
        phase_summary = create_phase_summary(session_id=session_id, phase_name=phase_name, **kwargs)
        self._save_entry(phase_summary)
        self._index_entry(phase_summary)
        
        self.manifest["phase_progression"][phase_name] = "completed"
        self.manifest["stats"]["completed_phases"] += 1
        
        # Advance current phase
        next_phase = _get_next_phase(phase_name)
        if next_phase:
            self.manifest["current_phase"] = next_phase
            self.manifest["phase_progression"][next_phase] = "active"
        
        self._save_manifest()
        self._regenerate_bootstrap()
        return phase_summary
    
    def get_context_for_goal(self, goal_id: str) -> Dict:
        """Get full context for a goal — everything an agent needs to work on it."""
        goal_path = self.root / "goals" / f"{goal_id}.json"
        with open(goal_path) as f:
            goal = json.load(f)
        
        context = {
            "goal": goal,
            "related_discoveries": [],
            "dependency_goals": [],
            "phase_context": None,
        }
        
        # Load related discoveries
        for disc_id in goal.get("discoveries", []):
            disc_path = self.root / "discoveries" / f"{disc_id}.json"
            if disc_path.exists():
                with open(disc_path) as f:
                    context["related_discoveries"].append(json.load(f))
        
        # Load dependency goals
        for dep_id in goal["connections"].get("depends_on_goals", []):
            dep_path = self.root / "goals" / f"{dep_id}.json"
            if dep_path.exists():
                with open(dep_path) as f:
                    context["dependency_goals"].append(json.load(f))
        
        # Load phase context
        for phase_file in (self.root / "phases").glob("*.json"):
            with open(phase_file) as f:
                phase = json.load(f)
                if phase["name"] == goal["phase"]:
                    context["phase_context"] = phase
                    break
        
        return context
    
    def query(
        self,
        category: Optional[str] = None,
        phase: Optional[str] = None,
        tags: Optional[List[str]] = None,
        status: Optional[str] = None,
    ) -> List[Dict]:
        """Query the manifest index with filters. Returns matching index entries."""
        results = []
        
        categories = [category] if category else ["discoveries", "goals", "accomplishments", "skills", "phases"]
        
        for cat in categories:
            for entry_id, entry_meta in self.manifest["index"].get(cat, {}).items():
                match = True
                if phase and entry_meta.get("phase") != phase:
                    match = False
                if tags and not set(tags).intersection(set(entry_meta.get("tags", []))):
                    match = False
                if status and entry_meta.get("status") != status:
                    match = False
                if match:
                    results.append({"id": entry_id, "category": cat, **entry_meta})
        
        return results
    
    def get_skills_for_phase(self, phase_name: str) -> List[Dict]:
        """Get all skills extracted from a specific phase.
        
        This is the 'fast path' — instead of replaying an entire phase,
        an agent can just load the skills to use its capabilities.
        """
        skills = []
        for skill_id, meta in self.manifest["index"].get("skills", {}).items():
            if meta.get("phase") == phase_name:
                skill_path = self.root / "skills" / f"{skill_id}.json"
                if skill_path.exists():
                    with open(skill_path) as f:
                        skills.append(json.load(f))
        return skills
    
    # ── Bootstrap Generation ──────────────────────────────────────────────
    
    def _regenerate_bootstrap(self):
        """Regenerate BOOTSTRAP.md — the single file a cold-start agent reads.
        
        This is the heart of the system. The bootstrap file gives any new
        agent instant understanding of:
        1. What this project is
        2. Where we are (current phase)
        3. What's been accomplished
        4. What's active right now
        5. What skills are available
        6. How to navigate the memory system
        """
        lines = []
        m = self.manifest
        
        lines.append("# 🧠 Project Memory — Bootstrap")
        lines.append(f"")
        lines.append(f"**Project:** {m.get('project_name', 'Unnamed')}")
        lines.append(f"**Current Phase:** {m['current_phase']}")
        lines.append(f"**Last Updated:** {m['last_updated']}")
        lines.append(f"")
        
        # Phase progression overview
        lines.append("## Phase Progression")
        lines.append("")
        for phase in PHASE_ORDER:
            status = m["phase_progression"].get(phase, "pending")
            icon = {"completed": "✅", "active": "🔄", "pending": "⏳"}.get(status, "❓")
            lines.append(f"- {icon} **{phase}** — {status}")
        lines.append("")
        
        # Completed phases with quick references
        completed_phases = [
            (pid, meta) for pid, meta in m["index"].get("phases", {}).items()
            if meta.get("status") == "completed"
        ]
        if completed_phases:
            lines.append("## Completed Phases")
            lines.append("")
            for pid, meta in sorted(completed_phases, key=lambda x: x[1].get("order", 0)):
                lines.append(f"### {meta['title']} (Phase: {meta.get('phase', pid)})")
                lines.append(f"- **File:** `phases/{pid}.json`")
                lines.append("")
        
        # Active goals
        active_goals = [
            (gid, meta) for gid, meta in m["index"].get("goals", {}).items()
            if meta.get("status") in ("active", "in_progress")
        ]
        if active_goals:
            lines.append("## Active Goals")
            lines.append("")
            for gid, meta in active_goals:
                status_icon = "🔄" if meta["status"] == "in_progress" else "📋"
                lines.append(f"- {status_icon} **{meta['title']}** [{meta.get('group', '')}] → `goals/{gid}.json`")
            lines.append("")
        
        # Recent accomplishments (last 10)
        accomplishments = list(m["index"].get("accomplishments", {}).items())
        accomplishments.sort(key=lambda x: x[1].get("timestamp", ""), reverse=True)
        if accomplishments:
            lines.append("## Recent Accomplishments")
            lines.append("")
            for aid, meta in accomplishments[:10]:
                lines.append(f"- ✅ **{meta['title']}** (phase: {meta.get('phase', '?')})")
                if meta.get("skills"):
                    lines.append(f"  - Skills: {', '.join(meta['skills'])}")
            lines.append("")
        
        # Available skills (the fast path)
        skills = m["index"].get("skills", {})
        if skills:
            lines.append("## Available Skills (Fast Path)")
            lines.append("")
            lines.append("*Use these instead of replaying completed phases:*")
            lines.append("")
            by_phase = {}
            for sid, meta in skills.items():
                phase = meta.get("phase", "unknown")
                by_phase.setdefault(phase, []).append((sid, meta))
            for phase in PHASE_ORDER:
                if phase in by_phase:
                    lines.append(f"### From phase: {phase}")
                    for sid, meta in by_phase[phase]:
                        lines.append(f"- **{meta['title']}** — {meta.get('usage', '')} → `skills/{sid}.json`")
                    lines.append("")
        
        # Recent discoveries (last 5)
        discoveries = list(m["index"].get("discoveries", {}).items())
        discoveries.sort(key=lambda x: x[1].get("timestamp", ""), reverse=True)
        if discoveries:
            lines.append("## Recent Discoveries")
            lines.append("")
            for did, meta in discoveries[:5]:
                lines.append(f"- 💡 **{meta['title']}** [{meta.get('direction', '')}] (phase: {meta.get('phase', '?')})")
            lines.append("")
        
        # Navigation guide
        lines.append("## How to Navigate This Memory")
        lines.append("")
        lines.append("1. **Need to work on a goal?** → Read the goal file, it has all connections")
        lines.append("2. **Need capabilities from a past phase?** → Read its skills in `skills/`")
        lines.append("3. **Need to understand WHY something was done?** → Check the discovery's `context.connects_to_plan`")
        lines.append("4. **Need the full history of a phase?** → Read `phases/{phase_id}.json`")
        lines.append("5. **Need to find something specific?** → Use `manifest.json` index with filters")
        lines.append("")
        
        # Active sessions warning
        active = m.get("active_sessions", [])
        if active:
            lines.append("## ⚠️ Active Sessions")
            lines.append("")
            lines.append(f"Sessions currently running: {', '.join(active)}")
            lines.append("Coordinate to avoid conflicts on shared goals.")
            lines.append("")
        
        # Stats
        lines.append("---")
        lines.append(f"*Stats: {m['stats']['total_discoveries']} discoveries, "
                     f"{m['stats']['total_goals']} goals, "
                     f"{m['stats']['total_accomplishments']} accomplishments, "
                     f"{m['stats']['total_skills']} skills, "
                     f"{m['stats']['completed_phases']} phases completed*")
        
        with open(self.bootstrap_path, "w") as f:
            f.write("\n".join(lines))
    
    def initialize_project(self, project_name: str, description: str = ""):
        """Initialize a new project with bootstrap file."""
        self.manifest["project_name"] = project_name
        self.manifest["phase_progression"][PHASE_ORDER[0]] = "active"
        self._save_manifest()
        self._regenerate_bootstrap()
        print(f"✅ Memory system initialized for: {project_name}")
        print(f"   Root: {self.root}")
        print(f"   Bootstrap: {self.bootstrap_path}")


# ─── Autonomous Agent Integration ─────────────────────────────────────────────

class AgentMemoryInterface:
    """High-level interface for autonomous agents.
    
    This is what agents actually interact with. It wraps MemoryStore
    with convenience methods that match how agents think and work.
    
    Usage:
        memory = AgentMemoryInterface(".memory")
        
        # Cold start — read bootstrap
        context = memory.bootstrap()
        
        # Start working
        session = memory.begin_session("coding-agent")
        
        # During work
        memory.note("Found that X requires Y", direction="executing", 
                     phase="walk", tags=["architecture"])
        
        # Complete work
        memory.finish_goal(goal_id, "Implemented X", skills=[...])
        
        # End session
        memory.end_session()
    """
    
    def __init__(self, root: str = DEFAULT_MEMORY_ROOT):
        self.store = MemoryStore(root)
        self.session_id: Optional[str] = None
        self._current_phase: Optional[str] = None
    
    def bootstrap(self) -> str:
        """Read the bootstrap file. This is step 1 for any cold-start agent."""
        if self.store.bootstrap_path.exists():
            with open(self.store.bootstrap_path) as f:
                return f.read()
        return "No bootstrap file found. Initialize with .initialize_project() first."
    
    def begin_session(self, agent_name: str = "default") -> str:
        """Start an isolated session. Returns session ID."""
        self.session_id = self.store.start_session(agent_name)
        self._current_phase = self.store.manifest["current_phase"]
        return self.session_id
    
    def end_session(self):
        """End the current session."""
        if self.session_id:
            self.store.end_session(self.session_id)
            self.session_id = None
    
    def note(
        self,
        content: str,
        title: Optional[str] = None,
        direction: str = "executing",
        phase: Optional[str] = None,
        goal_id: Optional[str] = None,
        plan_connection: Optional[str] = None,
        enables: Optional[List[str]] = None,
        depends_on: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> Dict:
        """Quick way to add a discovery during work."""
        if not self.session_id:
            raise RuntimeError("No active session. Call begin_session() first.")
        
        if not title:
            # Auto-generate title from first ~60 chars
            title = content[:60].strip()
            if len(content) > 60:
                title += "..."
        
        return self.store.add_discovery(
            session_id=self.session_id,
            title=title,
            content=content,
            context_direction=direction,
            phase=phase or self._current_phase or "unknown",
            relates_to_goal=goal_id,
            connects_to_plan=plan_connection,
            enables_future=enables,
            depends_on=depends_on,
            tags=tags,
        )
    
    def set_goal(
        self,
        title: str,
        description: str,
        group: str,
        intended_effect: str,
        enables_existing: str = "",
        opens_doors: Optional[List[str]] = None,
        depends_on: Optional[List[str]] = None,
        criteria: Optional[List[str]] = None,
        phase: Optional[str] = None,
    ) -> Dict:
        """Set a new goal with full context."""
        if not self.session_id:
            raise RuntimeError("No active session. Call begin_session() first.")
        
        return self.store.add_goal(
            session_id=self.session_id,
            title=title,
            description=description,
            phase=phase or self._current_phase or "unknown",
            group=group,
            intended_effect=intended_effect,
            enables_for_existing=enables_existing,
            opens_doors_to=opens_doors or [],
            depends_on_goals=depends_on,
            acceptance_criteria=criteria,
        )
    
    def finish_goal(
        self,
        goal_id: str,
        summary: str,
        skills: Optional[List[Dict]] = None,
    ) -> Dict:
        """Complete a goal, optionally extracting skills."""
        return self.store.complete_goal_by_id(goal_id, summary, skills)
    
    def get_skills(self, phase: Optional[str] = None) -> List[Dict]:
        """Get available skills, optionally filtered by phase."""
        if phase:
            return self.store.get_skills_for_phase(phase)
        # All skills
        all_skills = []
        for p in PHASE_ORDER:
            all_skills.extend(self.store.get_skills_for_phase(p))
        return all_skills
    
    def find(self, **filters) -> List[Dict]:
        """Search the memory index."""
        return self.store.query(**filters)
    
    def context_for(self, goal_id: str) -> Dict:
        """Get everything needed to work on a specific goal."""
        return self.store.get_context_for_goal(goal_id)
    
    def initialize_project(self, name: str, description: str = ""):
        """Initialize a new project."""
        self.store.initialize_project(name, description)


# ─── CLI Interface ────────────────────────────────────────────────────────────

def main():
    """Simple CLI for testing and manual operations."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Memory System CLI")
    parser.add_argument("--root", default=DEFAULT_MEMORY_ROOT, help="Memory root directory")
    
    sub = parser.add_subparsers(dest="command")
    
    # init
    init_cmd = sub.add_parser("init", help="Initialize a new project")
    init_cmd.add_argument("name", help="Project name")
    
    # status
    sub.add_parser("status", help="Show current memory status")
    
    # bootstrap
    sub.add_parser("bootstrap", help="Print bootstrap file")
    
    args = parser.parse_args()
    
    memory = AgentMemoryInterface(args.root)
    
    if args.command == "init":
        memory.initialize_project(args.name)
    elif args.command == "status":
        m = memory.store.manifest
        print(f"Project: {m.get('project_name', 'N/A')}")
        print(f"Phase: {m['current_phase']}")
        print(f"Active sessions: {len(m['active_sessions'])}")
        print(f"Stats: {json.dumps(m['stats'], indent=2)}")
    elif args.command == "bootstrap":
        print(memory.bootstrap())
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
