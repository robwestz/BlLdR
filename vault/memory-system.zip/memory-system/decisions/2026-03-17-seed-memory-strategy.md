# Decision: Seed Memory Strategy for SDK-Factory

**Datum:** 2026-03-17
**Beslutare:** @robin + orchestrator
**Status:** Aktiv

## Kontext

SDK-Factory har bootstrappats med 15K+ LOC och 437 tester, men saknar
seed memories. Utan minnen måste varje ny agent läsa hela kodbasen
för att förstå mönster, konventioner och kända fallgropar.

## Alternativ

### A: Organisk ackumulering (rejected)
Låt minnen växa naturligt genom sessions.
- Pro: Inget extra arbete
- Con: Första 5-10 sessions misslyckas på kända problem, brus ackumuleras

### B: Manuell dump (rejected)
Skriv alla insikter i en stor CLAUDE.md.
- Pro: Snabbt
- Con: Ingen kompositionseffekt, inget kvalitetsgate, inte maskinläsbart

### C: Memory Builder Team — strategisk design (vald)
3-agent-pipeline (Researcher → Gatekeeper → Installer) med 5 kvalitetsgate,
3 progressiva batcher (contracts → process → guardrails), filbaserad installation.
- Pro: Kvalitetssäkrat, komposition, verifierbart, maskinläsbart
- Con: Mer uppfront-arbete, kräver verifiering per batch

## Beslut

Alternativ C. Anpassat Memory Builder Team-ramverk med SDK-Factory-specifika
batcher som mappar till krypa→gå→springa-faser.

## Rationale

1. Quality gates förhindrar brus — bara verifierade mönster installeras
2. Kompositionseffekt — minnen samverkar och öppnar emergenta kapabiliteter
3. ContextRetriever hittar minnen automatiskt — agenter behöver inte veta om dem
4. Progressiva faser (krypa→gå→springa) matchar SDK-Factory's egna minnesmönster
5. Verifiering per batch ger snabb feedback om något inte fungerar

## Vad som ändrar detta beslut

- Om ContextRetriever visar sig för svag för keyword-matching → migrera till
  vector store (VectorStoreClient redan stubbad)
- Om 3 batcher visar sig otillräckliga → lägg till batch 4+ som tematiska tillägg
- Om agent-performance inte förbättras mätbart → ompröva hela strategin

## Beroenden

- Kräver: SDK-Factory kodbas (klar), Memory Builder Team-ramverk (klar)
- Blockerar: Första autonoma projektet (väntar på batch 1-3)
