# Tools Manifest

Läs denna fil innan du skapar nya verktyg. Om ett verktyg redan finns — använd det.

| Verktyg | Syfte | Input | Output |
|---------|-------|-------|--------|
| `continuum-write.sh` | Skriv discovery (med secret guard) | `--session --engine --topic --content [--type --artifacts --project]` | JSON-rad i discoveries.jsonl |
| `context-load.sh` | Smart context-laddning (multi-signal auto-tier) | `[--tier hot/warm/cold] [--budget N] [--refresh] [--reflect] [--json] [--domain D]` | stdout (markdown eller JSON) |
| `inject-context.sh` | Injicera discoveries till CLAUDE.md | discoveries.jsonl + CLAUDE.md med markers | Uppdaterad CLAUDE.md |
| `session-brief.sh` | Generera hot-tier brief | discoveries.jsonl + PROJECT.md | context/session-brief.md |
| `distill-discoveries.sh` | Komprimera discoveries per topic | discoveries.jsonl | context/distilled.md |
| `session-handoff.sh` | Skapa handoff-kontrakt | git diff + discoveries | context/handoff.md |
| `doctor.sh` | Health check (dirs, config, jsonl, markers, identity, tools, deps, staleness) | `[--verbose]` | OK / issues med fix-förslag |
| `auto-discovery.sh` | Mina git commits till discoveries (0 LLM-tokens) | `[--since DATE] [--dry-run]` | JSON-rader i discoveries.jsonl |
| `session-track.sh` | Spåra session-livscykel | `--start / --end [--session ID] / --list` | Session JSON i continuum/sessions/ |
| `checkpoint.sh` | Snapshot state till checkpoints | `[--slug NAME] [--auto] [--threshold N]` | Checkpoint-mapp med manifest |
| `session-start.sh` | Ett-kommando sessionsstart (auto-discovery + track + doctor + context) | `[--tier T] [--budget N] [--skip-doctor] [--engine E]` | Context till stdout |
| `session-end.sh` | Ett-kommando sessionsslut (discovery + handoff + brief + distill + inject + checkpoint + track) | `--session S --summary "..." [--skip-inject] [--skip-checkpoint]` | Alla artifacts uppdaterade |
| `auto-skill.sh` | Auto skill-generering från discoveries-mönster | `[--detect] [--generate] [--guardrails] [--distill] [--distill-model M] [--min-count N] [--dry-run]` | Skills i .ultima/skills/, _index.json |
| `distill-skill.sh` | Standalone LLM-destillering av discoveries per topic | `--topic T [--model M] [--dry-run] [--min-count N]` | Destillerad skill.md + _index.json |
| `_common.sh` | Delade helpers (source, kör inte direkt) | — | `winpath()`, `resolve_python()`, `read_arg()` |

## Regler

- Varje nytt tool MÅSTE registreras här med en rad
- Tools gör **ett jobb** — deterministiskt, stdin/stdout
- `set -euo pipefail` i alla bash-scripts
- Testa att det fungerar innan du går vidare
- Portabilitet: Linux, macOS, Windows (Git Bash)
